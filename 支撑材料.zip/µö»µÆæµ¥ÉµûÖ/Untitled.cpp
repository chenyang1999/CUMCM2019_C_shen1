#include<iostream>
#include<cstdio>
using namespace std;

float T(int t){
	if(t<=5*60 ||t>=23*60)return 0.45;
	else return 0.15;
}

float W(int t){
	if(w)
}