import gzip
import io

def gzip_str(string_):
	out = io.BytesIO()

	with gzip.GzipFile(fileobj=out, mode='w') as fo:
		fo.write(string_.encode())

	bytes_obj = out.getvalue()
	return bytes_obj

def gunzip_bytes_obj(bytes_obj):
	in_ = io.BytesIO()
	in_.write(bytes_obj)
	in_.seek(0)
	with gzip.GzipFile(fileobj=in_, mode='rb') as fo:
		gunzipped_bytes_obj = fo.read()

	return gunzipped_bytes_obj.decode()
	
	
string_ = 'String encoding = System.getProperty("file.encoding", "UTF-8");'

gzipped_bytes = gzip_str(string_)

original_string = gunzip_bytes_obj(gzipped_bytes)
print(gzipped_bytes,original_string)